#ifndef COMPAT_LINUX_CGROUP_RDMA_H
#define COMPAT_LINUX_CGROUP_RDMA_H

#include "../../compat/config.h"

#ifdef HAVE_CGROUP_RDMA_H
#include_next <linux/cgroup_rdma.h>
#endif

#endif /* COMPAT_LINUX_CGROUP_RDMA_H */
