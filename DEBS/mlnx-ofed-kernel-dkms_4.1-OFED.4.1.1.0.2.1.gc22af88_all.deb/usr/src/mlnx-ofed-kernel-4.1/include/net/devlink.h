#ifndef _COMPAT_NET_devlink_H
#define _COMPAT_NET_devlink_H 1

#include "../../compat/config.h"

#ifdef HAVE_DEVLINK_H
#include_next <net/devlink.h>
#endif

#endif	/* _COMPAT_NET_DEVLINK_H */
