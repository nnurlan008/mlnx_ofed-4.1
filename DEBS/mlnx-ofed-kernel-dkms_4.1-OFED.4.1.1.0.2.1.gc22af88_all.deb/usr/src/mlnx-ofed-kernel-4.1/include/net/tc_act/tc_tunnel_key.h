#ifndef _COMPAT_NET_TC_ACT_TC_TUNNEL_KEY_H
#define _COMPAT_NET_TC_ACT_TC_TUNNEL_KEY_H 1

#include "../../../compat/config.h"

#ifdef HAVE_NET_TC_ACT_TC_TUNNEL_KEY_H
#include_next <net/tc_act/tc_tunnel_key.h>
#endif

#endif	/* _COMPAT_NET_TC_ACT_TC_TUNNEL_KEY_H */
