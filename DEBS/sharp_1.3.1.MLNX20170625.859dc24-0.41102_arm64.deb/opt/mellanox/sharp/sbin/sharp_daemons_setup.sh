#!/bin/bash
#
# Copyright (C) Mellanox Technologies Ltd. 2016-2017.  ALL RIGHTS RESERVED.
# See file LICENSE for terms.
#

if [ $(whoami) != "root" ]; then
	echo "Error: root permission required. Exit."
	exit 1
fi

distro_name=$(python -c 'import platform ; print platform.dist()[0]' | tr '[:upper:]' '[:lower:]')

add_serv()
{
	serv=$1

	case $distro_name in
		'ubuntu') update-rc.d $serv defaults &> /dev/null ;;
		*)        chkconfig --add $serv &> /dev/null      ;;
	esac
}

rm_serv()
{
	serv=$1

	case $distro_name in
		'ubuntu') (ls /etc/rc*.d | grep -q $serv) &> /dev/null && update-rc.d -f $serv remove &> /dev/null ;;
		*)        (chkconfig --list | grep $serv) &> /dev/null && chkconfig --del $serv &> /dev/null       ;;
	esac
}

unset_level()
{
	serv=$1

	case $distro_name in
		'ubuntu') update-rc.d $serv disable 0123456 &> /dev/null   ;;
		*)        chkconfig --level 0123456 $serv off &> /dev/null ;;
	esac
}

is_added()
{
	serv=$1
	ok=1

	case $distro_name in
		'ubuntu') ls /etc/rc*.d | grep -q $serv && ok=0                ;;
		*)        (chkconfig --list | grep $serv) &> /dev/null && ok=0 ;;
	esac

	if [ $ok -eq 0 ]; then
		echo "Service $serv is installed"
		return 0
	else
		echo "Error: failed to install service $serv"
		return 1
	fi
}

is_removed()
{
	serv=$1
	ok=1

	case $distro_name in
		'ubuntu') ! (ls /etc/rc*.d | grep -q $serv) && ok=0              ;;
		*)        ! (chkconfig --list | grep $serv) &> /dev/null && ok=0 ;;
	esac
    
	if [ $ok -eq 0 ]; then
		echo "Service $serv is removed"
		return 0
	else
		echo "Error: failed to remove service $serv"
		return 1
	fi
}

# $1 - service name
monit_add()
{
	SERVICE=$1
	MONIT_DIR=/etc/monit.d
	MONIT_FILE=$MONIT_DIR/${SERVICE}.conf
	TMP_F=/tmp/${SERVICE}_$$.conf
	
	if [ ! -d $MONIT_DIR ]; then
		echo "Warning: Seems like monit package is not installed. ${SERVICE} will not be monitored."
		return 1
	fi
	
	cat > $TMP_F << EOF
check process $SERVICE with pidfile /var/run/${SERVICE}.pid
	start program = "/etc/init.d/$SERVICE start"
	stop program = "/etc/init.d/$SERVICE stop"
	if 50 restarts within 50 cycles then timeout
EOF

	cp $TMP_F $MONIT_FILE &> /dev/null
	pkill -1 monit &> /dev/null
}

# $1 - service name
monit_remove()
{
	SERVICE=$1
	MONIT_DIR=/etc/monit.d
	MONIT_FILE=$MONIT_DIR/${SERVICE}.conf
	
	[ ! -d $MONIT_DIR ] && return 1
	
	rm -f $MONIT_FILE &> /dev/null
	pkill -1 monit &> /dev/null
}

# $1 - SHARP location dir
# $2 - list of daemons
# $3 - monit flag
setup()
{
	init=$1/sbin/sharp.init

	if [ ! -f "$init" ]; then
		echo "Error: $init doesn't exist. Exit."
		exit 3
	fi

	chmod 755 $init
 
	for daemon in $2; do
		ln -sf $init /etc/init.d/$daemon &>/dev/null
		add_serv $daemon

		[ $daemon = "sharp_am" ] && unset_level sharp_am

		is_added $daemon
		
		[ $? -eq 0 ] && [ -n "$3" ] && monit_add $daemon
	done
}

# $1 - list of daemons
unsetup()
{
	for daemon in $1; do
		[ -x /etc/init.d/$daemon ] && /etc/init.d/$daemon stop
		pkill $daemon &>/dev/null
		rm -f /tmp/d_${daemon}.log /var/run/{$daemon}.pid &> /dev/null

		rm -f /etc/init.d/$daemon &> /dev/null
		rm_serv $daemon
 
		is_removed $daemon
		
		[ $? -eq 0 ] && monit_remove $daemon
	done
}

usage()
{
	echo "Usage: `basename $0` (-s | -r) [-p SHARP location dir] -d <sharpd | sharp_am> [-m]"
	echo "	-s - Setup SHARP daemon"
	echo "	-r - Remove SHARP daemon"
	echo "	-p - Path to alternative SHARP location dir"
	echo "	-d - Daemon name (sharpd or sharp_am)"
	echo "	-m - Add monit capability for daemon control"

	exit 2
}

dlist=""
location_dir=""
to_setup=""
to_remove=""
to_monit=""
while getopts "sp:rd:m" flag_arg; do
	case $flag_arg in
		s) to_setup="yes"         ;;
		r) to_remove="yes"        ;;
		p) location_dir="$OPTARG" ;;
		d) dlist="$OPTARG"        ;;
		m) to_monit="yes"         ;;
		*) usage                  ;;
	esac
done

([ $OPTIND -eq 1 ] || [ -z "$dlist" ]) && usage

[[ -z ${to_setup} && -z ${to_remove} ]] && usage 
[[ -n ${to_setup} && -n ${to_remove} ]] && usage 

[ -z "$location_dir" ] && _dir=$(readlink -f $(dirname $0)/..)

for daemon in $dlist; do
	([ $daemon != "sharpd" ] && [ $daemon != "sharp_am" ]) && usage
	
	[ -z "$location_dir" ] && [ -f "$_dir/bin/$daemon" ] && location_dir=$_dir
done

[ -n "$to_setup" ] && setup "$location_dir" "$dlist" "$to_monit"
[ -n "$to_remove" ] && unsetup "$dlist"

exit 0
