#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xde725ad8, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x5b48a1ad, __VMLINUX_SYMBOL_STR(alloc_pages_current) },
	{ 0x2d3385d3, __VMLINUX_SYMBOL_STR(system_wq) },
	{ 0x705b977d, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0xd2b09ce5, __VMLINUX_SYMBOL_STR(__kmalloc) },
	{ 0xa3e17f56, __VMLINUX_SYMBOL_STR(node_to_cpumask_map) },
	{ 0x1fdc7df2, __VMLINUX_SYMBOL_STR(_mcount) },
	{ 0x17a142df, __VMLINUX_SYMBOL_STR(__copy_from_user) },
	{ 0xd6ee688f, __VMLINUX_SYMBOL_STR(vmalloc) },
	{ 0xda3b935b, __VMLINUX_SYMBOL_STR(param_ops_int) },
	{ 0x98082893, __VMLINUX_SYMBOL_STR(__copy_to_user) },
	{ 0x6c09c2a4, __VMLINUX_SYMBOL_STR(del_timer) },
	{ 0x60a13e90, __VMLINUX_SYMBOL_STR(rcu_barrier) },
	{ 0xc05fce8d, __VMLINUX_SYMBOL_STR(remap_vmalloc_range) },
	{ 0x18fef9cb, __VMLINUX_SYMBOL_STR(xen_start_info) },
	{ 0x79aa04a2, __VMLINUX_SYMBOL_STR(get_random_bytes) },
	{ 0xd25e16e3, __VMLINUX_SYMBOL_STR(remove_wait_queue) },
	{ 0xafd38a4f, __VMLINUX_SYMBOL_STR(set_page_dirty_lock) },
	{ 0x9580deb, __VMLINUX_SYMBOL_STR(init_timer_key) },
	{ 0x999e8297, __VMLINUX_SYMBOL_STR(vfree) },
	{ 0xa9b248b6, __VMLINUX_SYMBOL_STR(idr_for_each) },
	{ 0x8407d681, __VMLINUX_SYMBOL_STR(kthread_create_on_node) },
	{ 0x7d11c268, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0x2008ead5, __VMLINUX_SYMBOL_STR(dma_find_channel) },
	{ 0xab40cca9, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0xffd5a395, __VMLINUX_SYMBOL_STR(default_wake_function) },
	{ 0xfe7c4287, __VMLINUX_SYMBOL_STR(nr_cpu_ids) },
	{ 0x2b1e2df8, __VMLINUX_SYMBOL_STR(dmaengine_unmap_put) },
	{ 0x14064e21, __VMLINUX_SYMBOL_STR(misc_register) },
	{ 0x706d051c, __VMLINUX_SYMBOL_STR(del_timer_sync) },
	{ 0xdcb764ad, __VMLINUX_SYMBOL_STR(memset) },
	{ 0x20906cd5, __VMLINUX_SYMBOL_STR(idr_destroy) },
	{ 0x74272ba8, __VMLINUX_SYMBOL_STR(xen_dma_ops) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0xd1a6879d, __VMLINUX_SYMBOL_STR(kthread_stop) },
	{ 0xa801ace, __VMLINUX_SYMBOL_STR(dmaengine_get_unmap_data) },
	{ 0x923b1276, __VMLINUX_SYMBOL_STR(dmaengine_get) },
	{ 0xa1c76e0a, __VMLINUX_SYMBOL_STR(_cond_resched) },
	{ 0xf8e398fc, __VMLINUX_SYMBOL_STR(memstart_addr) },
	{ 0x37cd41ed, __VMLINUX_SYMBOL_STR(set_cpus_allowed_ptr) },
	{ 0x84ffea8b, __VMLINUX_SYMBOL_STR(idr_preload) },
	{ 0x7c173634, __VMLINUX_SYMBOL_STR(__bitmap_complement) },
	{ 0x16e5c2a, __VMLINUX_SYMBOL_STR(mod_timer) },
	{ 0xa850dafc, __VMLINUX_SYMBOL_STR(idr_alloc) },
	{ 0x42160169, __VMLINUX_SYMBOL_STR(flush_workqueue) },
	{ 0xb4fc735b, __VMLINUX_SYMBOL_STR(idr_remove) },
	{ 0xc6cbbc89, __VMLINUX_SYMBOL_STR(capable) },
	{ 0x959bf72c, __VMLINUX_SYMBOL_STR(__free_pages) },
	{ 0xaacc3134, __VMLINUX_SYMBOL_STR(idr_find_slowpath) },
	{ 0x5635a60a, __VMLINUX_SYMBOL_STR(vmalloc_user) },
	{ 0x1000e51, __VMLINUX_SYMBOL_STR(schedule) },
	{ 0x30f18f9a, __VMLINUX_SYMBOL_STR(wake_up_process) },
	{ 0x497a6fed, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0x5cd885d5, __VMLINUX_SYMBOL_STR(_raw_spin_lock) },
	{ 0xd3bb179d, __VMLINUX_SYMBOL_STR(dummy_dma_ops) },
	{ 0x65345022, __VMLINUX_SYMBOL_STR(__wake_up) },
	{ 0xb3f7646e, __VMLINUX_SYMBOL_STR(kthread_should_stop) },
	{ 0xcb128141, __VMLINUX_SYMBOL_STR(prepare_to_wait_event) },
	{ 0x9bc6ef31, __VMLINUX_SYMBOL_STR(add_wait_queue) },
	{ 0x57575f08, __VMLINUX_SYMBOL_STR(dmaengine_put) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x4829a47e, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0x643e0ce5, __VMLINUX_SYMBOL_STR(call_rcu_sched) },
	{ 0x731dba7a, __VMLINUX_SYMBOL_STR(xen_domain_type) },
	{ 0x5cd6c5d4, __VMLINUX_SYMBOL_STR(put_page) },
	{ 0x4ca9669f, __VMLINUX_SYMBOL_STR(scnprintf) },
	{ 0x9c5bc552, __VMLINUX_SYMBOL_STR(finish_wait) },
	{ 0x2e0d2f7f, __VMLINUX_SYMBOL_STR(queue_work_on) },
	{ 0x28318305, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0x5068ae96, __VMLINUX_SYMBOL_STR(vmalloc_to_page) },
	{ 0x6f5ec7ec, __VMLINUX_SYMBOL_STR(idr_init) },
	{ 0x938ab2d9, __VMLINUX_SYMBOL_STR(param_ops_ulong) },
	{ 0xe2ae8066, __VMLINUX_SYMBOL_STR(param_ops_uint) },
	{ 0x6a531583, __VMLINUX_SYMBOL_STR(misc_deregister) },
	{ 0x407ef185, __VMLINUX_SYMBOL_STR(get_user_pages_fast) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "7C680C2F96087C11DC47FD6");
